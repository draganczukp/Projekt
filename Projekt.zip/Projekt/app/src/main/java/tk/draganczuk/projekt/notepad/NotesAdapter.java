package tk.draganczuk.projekt.notepad;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import lombok.AllArgsConstructor;
import tk.draganczuk.projekt.R;

@AllArgsConstructor
public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.ViewHolder> {

    private List<NoteModel> notes;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View contactView = inflater.inflate(R.layout.item_note, parent, false);

        return new ViewHolder(contactView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NoteModel note = notes.get(position);

        TextView noteTitleView = holder.noteTitleView;
        TextView noteContentView = holder.noteContentView;
        Button editButton = holder.editButton;

        noteTitleView.setText(note.getTitle());
        noteContentView.setText(note.getContent());
        editButton.setOnClickListener(EditNoteActivity.getEditButtonClickListener(note));
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView noteTitleView;
        TextView noteContentView;
        Button editButton;

        ViewHolder(View itemView) {
            super(itemView);
            noteTitleView = itemView.findViewById(R.id.noteListTitle);
            noteContentView = itemView.findViewById(R.id.noteListContent);
            editButton = itemView.findViewById(R.id.noteListEditButton);
        }
    }
}