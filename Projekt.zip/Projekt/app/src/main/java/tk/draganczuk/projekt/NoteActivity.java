package tk.draganczuk.projekt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import tk.draganczuk.projekt.notepad.AllNotesActivity;
import tk.draganczuk.projekt.notepad.EditNoteActivity;

public class NoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
    }

    public void onNewButton(View view){
        startActivity(new Intent(getApplicationContext(), EditNoteActivity.class));
    }

    public void onShowAll(View view){
        startActivity(new Intent(getApplicationContext(), AllNotesActivity.class));
    }

    public void onFindButon(View view){
        notImplemented();
    }

    public void onDeleteButton(View view){
        notImplemented();
    }

    private void notImplemented() {
        Toast.makeText(getApplicationContext(), "NOT IMPLEMENTED", Toast.LENGTH_LONG).show();
    }
}
